import { firebaseConfig, companyDefaults } from './firebase-config.js';
import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.12.1/firebase-app.js';
import {
  getAuth,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
  signOut,
  deleteUser
} from 'https://www.gstatic.com/firebasejs/12.12.1/firebase-auth.js';
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  setDoc,
  addDoc,
  updateDoc,
  onSnapshot,
  query,
  where,
  serverTimestamp,
  increment
} from 'https://www.gstatic.com/firebasejs/12.12.1/firebase-firestore.js';

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const els = {
  toast: byId('toast'),
  authView: byId('auth-view'),
  employeeView: byId('employee-view'),
  adminView: byId('admin-view'),
  noAccessView: byId('no-access-view'),
  topActions: byId('top-actions'),
  sessionLabel: byId('session-label'),
  logoutBtn: byId('logout-btn'),
  noAccessLogoutBtn: byId('no-access-logout-btn'),
  loginForm: byId('login-form'),
  signupForm: byId('signup-form'),
  resetPasswordBtn: byId('reset-password-btn'),
  employeeTitle: byId('employee-title'),
  employeeStatusBadge: byId('employee-status-badge'),
  clockDate: byId('clock-date'),
  clockTime: byId('clock-time'),
  openShiftPill: byId('open-shift-pill'),
  breakMinutes: byId('break-minutes'),
  clockInBtn: byId('clock-in-btn'),
  clockOutBtn: byId('clock-out-btn'),
  manualEntryForm: byId('manual-entry-form'),
  leaveRequestForm: byId('leave-request-form'),
  leaveStart: byId('leave-start'),
  leaveEnd: byId('leave-end'),
  leaveDays: byId('leave-days'),
  employeeTimeBody: byId('employee-time-body'),
  employeeLeaveBody: byId('employee-leave-body'),
  metricLeaveBalance: byId('metric-leave-balance'),
  metricLeaveTaken: byId('metric-leave-taken'),
  metricLeavePending: byId('metric-leave-pending'),
  metricMonthHours: byId('metric-month-hours'),
  inviteForm: byId('invite-form'),
  companyForm: byId('company-form'),
  adminUsersBody: byId('admin-users-body'),
  adminInvitesBody: byId('admin-invites-body'),
  adminTimeBody: byId('admin-time-body'),
  adminLeaveBody: byId('admin-leave-body'),
  adminStatusFilter: byId('admin-status-filter'),
  adminActiveUsers: byId('admin-active-users'),
  adminOpenShifts: byId('admin-open-shifts'),
  adminPendingLeaves: byId('admin-pending-leaves'),
  adminMonthHours: byId('admin-month-hours'),
  exportCsvBtn: byId('export-csv-btn')
};

const state = {
  user: null,
  profile: null,
  company: { ...companyDefaults },
  openShift: null,
  employeeEntries: [],
  employeeLeaves: [],
  adminUsers: [],
  adminInvites: [],
  adminEntries: [],
  adminLeaves: [],
  unsubscribers: []
};

initUi();
startClock();

onAuthStateChanged(auth, async (user) => {
  clearSubscriptions();
  state.user = user;
  state.profile = null;

  if (!user) {
    showOnly('auth');
    els.topActions.classList.add('hidden');
    return;
  }

  els.topActions.classList.remove('hidden');
  els.sessionLabel.textContent = user.email || 'Connecté';

  try {
    const profile = await getOrCreateInvitedProfile(user);
    if (!profile || profile.active === false) {
      showOnly('no-access');
      return;
    }

    state.profile = profile;
    await loadCompanySettings();

    if (profile.role === 'admin') {
      showOnly('admin');
      subscribeAdmin();
    } else {
      showOnly('employee');
      subscribeEmployee();
    }
  } catch (error) {
    console.error(error);
    showOnly('no-access');
    toast(error.message || 'Impossible de charger le compte.', 'error');
  }
});

function initUi() {
  document.querySelectorAll('[data-auth-tab]').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelectorAll('[data-auth-tab]').forEach((tab) => tab.classList.remove('active'));
      button.classList.add('active');
      const tab = button.dataset.authTab;
      els.loginForm.classList.toggle('hidden', tab !== 'login');
      els.signupForm.classList.toggle('hidden', tab !== 'signup');
    });
  });

  const today = todayISO();
  byId('manual-date').value = today;
  byId('leave-start').value = today;
  byId('leave-end').value = today;
  byId('company-year').value = new Date().getFullYear();
  recomputeLeaveDays();

  els.loginForm.addEventListener('submit', handleLogin);
  els.signupForm.addEventListener('submit', handleSignup);
  els.resetPasswordBtn.addEventListener('click', handlePasswordReset);
  els.logoutBtn.addEventListener('click', () => signOut(auth));
  els.noAccessLogoutBtn.addEventListener('click', () => signOut(auth));
  els.clockInBtn.addEventListener('click', handleClockIn);
  els.clockOutBtn.addEventListener('click', handleClockOut);
  els.manualEntryForm.addEventListener('submit', handleManualEntry);
  els.leaveRequestForm.addEventListener('submit', handleLeaveRequest);
  els.leaveStart.addEventListener('change', recomputeLeaveDays);
  els.leaveEnd.addEventListener('change', recomputeLeaveDays);
  els.inviteForm.addEventListener('submit', handleInviteEmployee);
  els.companyForm.addEventListener('submit', handleCompanySave);
  els.adminUsersBody.addEventListener('click', handleAdminUserAction);
  els.adminTimeBody.addEventListener('click', handleAdminTimeAction);
  els.adminLeaveBody.addEventListener('click', handleAdminLeaveAction);
  els.adminStatusFilter.addEventListener('change', renderAdminEntries);
  els.exportCsvBtn.addEventListener('click', exportEntriesCsv);
}

async function handleLogin(event) {
  event.preventDefault();
  const email = byId('login-email').value.trim();
  const password = byId('login-password').value;
  try {
    await signInWithEmailAndPassword(auth, email, password);
    toast('Connexion réussie.', 'success');
  } catch (error) {
    toast(readableAuthError(error), 'error');
  }
}

async function handleSignup(event) {
  event.preventDefault();
  const displayName = byId('signup-name').value.trim();
  const email = byId('signup-email').value.trim();
  const password = byId('signup-password').value;

  try {
    const credentials = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(credentials.user, { displayName });
    await createProfileFromInvitation(credentials.user, displayName);
    toast('Compte salarié créé.', 'success');
  } catch (error) {
    if (auth.currentUser && error.message?.includes('invitation')) {
      try { await deleteUser(auth.currentUser); } catch (_) { /* ignore */ }
    }
    toast(readableAuthError(error), 'error');
  }
}

async function handlePasswordReset() {
  const email = byId('login-email').value.trim();
  if (!email) {
    toast('Saisissez votre email dans le formulaire de connexion.', 'error');
    return;
  }
  try {
    await sendPasswordResetEmail(auth, email);
    toast('Email de réinitialisation envoyé.', 'success');
  } catch (error) {
    toast(readableAuthError(error), 'error');
  }
}

async function getOrCreateInvitedProfile(user) {
  const userRef = doc(db, 'users', user.uid);
  const userSnap = await getDoc(userRef);
  if (userSnap.exists()) return { id: user.uid, ...userSnap.data() };

  return await createProfileFromInvitation(user, user.displayName || 'Salarié');
}

async function createProfileFromInvitation(user, fallbackName) {
  if (!user.email) throw new Error('Aucun email trouvé sur ce compte.');

  const inviteRef = doc(db, 'invitations', user.email.trim());
  const inviteSnap = await getDoc(inviteRef);
  if (!inviteSnap.exists()) {
    throw new Error('Aucune invitation trouvée pour cet email.');
  }

  const invite = inviteSnap.data();
  const profile = {
    email: user.email,
    displayName: invite.displayName || fallbackName,
    role: 'employee',
    active: true,
    weeklyHours: numberOr(invite.weeklyHours, 35),
    annualPaidLeaveDays: numberOr(invite.annualPaidLeaveDays, 30),
    leaveBalanceDays: numberOr(invite.leaveBalanceDays, 30),
    leaveTakenDays: 0,
    companyId: 'main',
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  };

  await setDoc(doc(db, 'users', user.uid), profile);

  try {
    await updateDoc(inviteRef, {
      status: 'accepted',
      uid: user.uid,
      acceptedAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  } catch (error) {
    console.warn('Invitation non mise à jour, profil créé malgré tout.', error);
  }

  return { id: user.uid, ...profile };
}

async function loadCompanySettings() {
  const ref = doc(db, 'companies', 'main');
  const snap = await getDoc(ref);
  state.company = snap.exists() ? { ...companyDefaults, ...snap.data() } : { ...companyDefaults };
  byId('company-name').value = state.company.name || companyDefaults.name;
  byId('company-email').value = state.company.contactEmail || '';
  byId('company-day-hours').value = state.company.standardDayHours || 7;
  byId('company-year').value = state.company.leaveYear || new Date().getFullYear();
}

function subscribeEmployee() {
  const profile = state.profile;
  els.employeeTitle.textContent = `Bonjour ${profile.displayName || ''}`.trim();
  els.employeeStatusBadge.textContent = profile.active ? 'Compte actif' : 'Compte inactif';
  renderEmployeeMetrics();

  const openQuery = query(
    collection(db, 'timeEntries'),
    where('uid', '==', state.user.uid),
    where('status', '==', 'open')
  );
  state.unsubscribers.push(onSnapshot(openQuery, (snapshot) => {
    state.openShift = snapshot.docs.map(docToObject)[0] || null;
    renderOpenShift();
  }, handleSnapshotError));

  const timeQuery = query(collection(db, 'timeEntries'), where('uid', '==', state.user.uid));
  state.unsubscribers.push(onSnapshot(timeQuery, (snapshot) => {
    state.employeeEntries = snapshot.docs.map(docToObject).sort(descByDateThenCreated);
    renderEmployeeEntries();
    renderEmployeeMetrics();
  }, handleSnapshotError));

  const leaveQuery = query(collection(db, 'leaveRequests'), where('uid', '==', state.user.uid));
  state.unsubscribers.push(onSnapshot(leaveQuery, (snapshot) => {
    state.employeeLeaves = snapshot.docs.map(docToObject).sort(descByCreated);
    renderEmployeeLeaves();
    renderEmployeeMetrics();
  }, handleSnapshotError));

  const profileRef = doc(db, 'users', state.user.uid);
  state.unsubscribers.push(onSnapshot(profileRef, (snapshot) => {
    if (snapshot.exists()) {
      state.profile = { id: state.user.uid, ...snapshot.data() };
      renderEmployeeMetrics();
    }
  }, handleSnapshotError));
}

function subscribeAdmin() {
  const usersRef = collection(db, 'users');
  state.unsubscribers.push(onSnapshot(usersRef, (snapshot) => {
    state.adminUsers = snapshot.docs.map(docToObject).sort((a, b) => (a.displayName || '').localeCompare(b.displayName || '', 'fr'));
    renderAdminUsers();
    renderAdminMetrics();
  }, handleSnapshotError));

  const invitesRef = collection(db, 'invitations');
  state.unsubscribers.push(onSnapshot(invitesRef, (snapshot) => {
    state.adminInvites = snapshot.docs.map(docToObject).sort(descByCreated);
    renderAdminInvites();
  }, handleSnapshotError));

  const entriesRef = collection(db, 'timeEntries');
  state.unsubscribers.push(onSnapshot(entriesRef, (snapshot) => {
    state.adminEntries = snapshot.docs.map(docToObject).sort(descByDateThenCreated);
    renderAdminEntries();
    renderAdminMetrics();
  }, handleSnapshotError));

  const leavesRef = collection(db, 'leaveRequests');
  state.unsubscribers.push(onSnapshot(leavesRef, (snapshot) => {
    state.adminLeaves = snapshot.docs.map(docToObject).sort(descByCreated);
    renderAdminLeaves();
    renderAdminMetrics();
  }, handleSnapshotError));
}

async function handleClockIn() {
  if (state.openShift) {
    toast('Une journée est déjà ouverte.', 'error');
    return;
  }

  try {
    const now = new Date();
    const location = await getLocation();
    await addDoc(collection(db, 'timeEntries'), {
      uid: state.user.uid,
      employeeName: state.profile.displayName || state.user.email,
      employeeEmail: state.user.email,
      date: toISODate(now),
      clockIn: now.toISOString(),
      clockOut: null,
      breakMinutes: 0,
      durationMinutes: 0,
      status: 'open',
      source: 'clock',
      locationIn: location,
      comment: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    toast('Arrivée pointée.', 'success');
  } catch (error) {
    console.error(error);
    toast('Impossible de pointer l’arrivée.', 'error');
  }
}

async function handleClockOut() {
  if (!state.openShift) {
    toast('Aucune journée ouverte.', 'error');
    return;
  }

  const breakMinutes = numberOr(els.breakMinutes.value, 0);
  const now = new Date();
  const total = computeDurationMinutes(state.openShift.clockIn, now.toISOString(), breakMinutes);

  if (total < 0) {
    toast('Durée incohérente. Vérifiez la pause.', 'error');
    return;
  }

  try {
    const location = await getLocation();
    await updateDoc(doc(db, 'timeEntries', state.openShift.id), {
      clockOut: now.toISOString(),
      breakMinutes,
      durationMinutes: total,
      status: 'submitted',
      locationOut: location,
      updatedAt: serverTimestamp()
    });
    els.breakMinutes.value = 0;
    toast('Départ pointé. Journée envoyée à validation.', 'success');
  } catch (error) {
    console.error(error);
    toast('Impossible de pointer le départ.', 'error');
  }
}

async function handleManualEntry(event) {
  event.preventDefault();
  const date = byId('manual-date').value;
  const start = byId('manual-start').value;
  const end = byId('manual-end').value;
  const breakMinutes = numberOr(byId('manual-break').value, 0);
  const comment = byId('manual-comment').value.trim();
  const startDate = new Date(`${date}T${start}:00`);
  const endDate = new Date(`${date}T${end}:00`);

  if (endDate <= startDate) {
    toast('L’heure de fin doit être après l’heure de début.', 'error');
    return;
  }

  const durationMinutes = computeDurationMinutes(startDate.toISOString(), endDate.toISOString(), breakMinutes);
  if (durationMinutes < 0) {
    toast('La pause est supérieure à la durée travaillée.', 'error');
    return;
  }

  try {
    await addDoc(collection(db, 'timeEntries'), {
      uid: state.user.uid,
      employeeName: state.profile.displayName || state.user.email,
      employeeEmail: state.user.email,
      date,
      clockIn: startDate.toISOString(),
      clockOut: endDate.toISOString(),
      breakMinutes,
      durationMinutes,
      status: 'submitted',
      source: 'manual',
      comment,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    els.manualEntryForm.reset();
    byId('manual-date').value = todayISO();
    byId('manual-break').value = 0;
    toast('Journée enregistrée.', 'success');
  } catch (error) {
    console.error(error);
    toast('Impossible d’enregistrer la journée.', 'error');
  }
}

async function handleLeaveRequest(event) {
  event.preventDefault();
  const startDate = byId('leave-start').value;
  const endDate = byId('leave-end').value;
  const days = numberOr(byId('leave-days').value, 0);

  if (!startDate || !endDate || days <= 0) {
    toast('Sélectionnez une période de congés valide.', 'error');
    return;
  }

  try {
    await addDoc(collection(db, 'leaveRequests'), {
      uid: state.user.uid,
      employeeName: state.profile.displayName || state.user.email,
      employeeEmail: state.user.email,
      type: byId('leave-type').value,
      startDate,
      endDate,
      days,
      status: 'pending',
      employeeComment: byId('leave-comment').value.trim(),
      adminResponse: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    byId('leave-comment').value = '';
    toast('Demande de congés envoyée.', 'success');
  } catch (error) {
    console.error(error);
    toast('Impossible d’envoyer la demande.', 'error');
  }
}

async function handleInviteEmployee(event) {
  event.preventDefault();
  const email = byId('invite-email').value.trim();
  const displayName = byId('invite-name').value.trim();

  try {
    await setDoc(doc(db, 'invitations', email), {
      email,
      displayName,
      weeklyHours: numberOr(byId('invite-weekly-hours').value, 35),
      annualPaidLeaveDays: numberOr(byId('invite-leave-balance').value, 30),
      leaveBalanceDays: numberOr(byId('invite-leave-balance').value, 30),
      status: 'pending',
      createdBy: state.user.uid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    }, { merge: true });
    els.inviteForm.reset();
    byId('invite-weekly-hours').value = 35;
    byId('invite-leave-balance').value = 30;
    toast('Invitation créée. Le salarié peut créer son compte.', 'success');
  } catch (error) {
    console.error(error);
    toast('Impossible de créer l’invitation.', 'error');
  }
}

async function handleCompanySave(event) {
  event.preventDefault();
  try {
    await setDoc(doc(db, 'companies', 'main'), {
      name: byId('company-name').value.trim() || 'SCEA du Bas de la CENSE',
      contactEmail: byId('company-email').value.trim(),
      standardDayHours: numberOr(byId('company-day-hours').value, 7),
      leaveYear: numberOr(byId('company-year').value, new Date().getFullYear()),
      updatedAt: serverTimestamp(),
      updatedBy: state.user.uid
    }, { merge: true });
    toast('Paramètres enregistrés.', 'success');
  } catch (error) {
    console.error(error);
    toast('Impossible d’enregistrer les paramètres.', 'error');
  }
}

async function handleAdminUserAction(event) {
  const button = event.target.closest('[data-action="save-user"]');
  if (!button) return;

  const row = button.closest('tr');
  const uid = row.dataset.uid;
  const weeklyHours = numberOr(row.querySelector('[data-field="weeklyHours"]').value, 35);
  const leaveBalanceDays = numberOr(row.querySelector('[data-field="leaveBalanceDays"]').value, 0);
  const leaveTakenDays = numberOr(row.querySelector('[data-field="leaveTakenDays"]').value, 0);
  const active = row.querySelector('[data-field="active"]').value === 'true';

  try {
    await updateDoc(doc(db, 'users', uid), {
      weeklyHours,
      leaveBalanceDays,
      leaveTakenDays,
      active,
      updatedAt: serverTimestamp(),
      updatedBy: state.user.uid
    });
    toast('Profil salarié mis à jour.', 'success');
  } catch (error) {
    console.error(error);
    toast('Impossible de mettre à jour le salarié.', 'error');
  }
}

async function handleAdminTimeAction(event) {
  const validateButton = event.target.closest('[data-action="validate-time"]');
  const reopenButton = event.target.closest('[data-action="reopen-time"]');
  const button = validateButton || reopenButton;
  if (!button) return;

  const entryId = button.dataset.id;
  const nextStatus = validateButton ? 'validated' : 'submitted';

  try {
    await updateDoc(doc(db, 'timeEntries', entryId), {
      status: nextStatus,
      validatedBy: validateButton ? state.user.uid : null,
      validatedAt: validateButton ? serverTimestamp() : null,
      updatedAt: serverTimestamp()
    });
    toast(validateButton ? 'Heures validées.' : 'Pointage remis à traiter.', 'success');
  } catch (error) {
    console.error(error);
    toast('Impossible de modifier ce pointage.', 'error');
  }
}

async function handleAdminLeaveAction(event) {
  const approveButton = event.target.closest('[data-action="approve-leave"]');
  const refuseButton = event.target.closest('[data-action="refuse-leave"]');
  const button = approveButton || refuseButton;
  if (!button) return;

  const requestId = button.dataset.id;
  const leave = state.adminLeaves.find((item) => item.id === requestId);
  if (!leave) return;

  const response = window.prompt('Commentaire administrateur :', approveButton ? 'Demande acceptée.' : 'Demande refusée.') || '';

  try {
    if (approveButton) {
      await updateDoc(doc(db, 'leaveRequests', requestId), {
        status: 'approved',
        adminResponse: response,
        decidedBy: state.user.uid,
        decidedAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      await updateDoc(doc(db, 'users', leave.uid), {
        leaveTakenDays: increment(numberOr(leave.days, 0)),
        leaveBalanceDays: increment(-numberOr(leave.days, 0)),
        updatedAt: serverTimestamp(),
        updatedBy: state.user.uid
      });
      toast('Congé accepté et compteur mis à jour.', 'success');
    } else {
      await updateDoc(doc(db, 'leaveRequests', requestId), {
        status: 'refused',
        adminResponse: response,
        decidedBy: state.user.uid,
        decidedAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      toast('Congé refusé.', 'success');
    }
  } catch (error) {
    console.error(error);
    toast('Impossible de traiter la demande de congé.', 'error');
  }
}

function renderOpenShift() {
  if (state.openShift) {
    els.openShiftPill.textContent = `Ouvert depuis ${formatTime(state.openShift.clockIn)}`;
    els.openShiftPill.className = 'pill open';
    els.clockInBtn.disabled = true;
    els.clockOutBtn.disabled = false;
  } else {
    els.openShiftPill.textContent = 'Aucune journée ouverte';
    els.openShiftPill.className = 'pill neutral';
    els.clockInBtn.disabled = false;
    els.clockOutBtn.disabled = true;
  }
}

function renderEmployeeEntries() {
  els.employeeTimeBody.innerHTML = state.employeeEntries.slice(0, 20).map((entry) => `
    <tr>
      <td>${escapeHtml(formatDate(entry.date))}</td>
      <td>${escapeHtml(formatTime(entry.clockIn))}</td>
      <td>${escapeHtml(formatTime(entry.clockOut))}</td>
      <td>${numberOr(entry.breakMinutes, 0)} min</td>
      <td>${formatHours(entry.durationMinutes)}</td>
      <td>${statusLabel(entry.status)}</td>
    </tr>
  `).join('') || emptyRow(6, 'Aucune heure déclarée.');
}

function renderEmployeeLeaves() {
  els.employeeLeaveBody.innerHTML = state.employeeLeaves.map((leave) => `
    <tr>
      <td>${escapeHtml(leave.type || '')}</td>
      <td>${escapeHtml(formatDate(leave.startDate))}</td>
      <td>${escapeHtml(formatDate(leave.endDate))}</td>
      <td>${numberOr(leave.days, 0)}</td>
      <td>${statusLabel(leave.status)}</td>
      <td>${escapeHtml(leave.adminResponse || '—')}</td>
    </tr>
  `).join('') || emptyRow(6, 'Aucune demande de congé.');
}

function renderEmployeeMetrics() {
  const profile = state.profile || {};
  els.metricLeaveBalance.textContent = formatNumber(profile.leaveBalanceDays);
  els.metricLeaveTaken.textContent = formatNumber(profile.leaveTakenDays);
  els.metricLeavePending.textContent = state.employeeLeaves.filter((leave) => leave.status === 'pending').length;
  els.metricMonthHours.textContent = formatNumber(minutesToHours(monthMinutes(state.employeeEntries)));
}

function renderAdminUsers() {
  els.adminUsersBody.innerHTML = state.adminUsers.map((user) => `
    <tr data-uid="${escapeAttr(user.id)}">
      <td><strong>${escapeHtml(user.displayName || '—')}</strong></td>
      <td>${escapeHtml(user.email || '—')}</td>
      <td>${roleLabel(user.role)}</td>
      <td><input type="number" data-field="weeklyHours" min="0" step="0.5" value="${numberOr(user.weeklyHours, 0)}" /></td>
      <td><input type="number" data-field="leaveBalanceDays" min="0" step="0.5" value="${numberOr(user.leaveBalanceDays, 0)}" /></td>
      <td><input type="number" data-field="leaveTakenDays" min="0" step="0.5" value="${numberOr(user.leaveTakenDays, 0)}" /></td>
      <td>
        <select data-field="active">
          <option value="true" ${user.active !== false ? 'selected' : ''}>Oui</option>
          <option value="false" ${user.active === false ? 'selected' : ''}>Non</option>
        </select>
      </td>
      <td><button class="btn secondary small" data-action="save-user">Enregistrer</button></td>
    </tr>
  `).join('') || emptyRow(8, 'Aucun profil.');
}

function renderAdminInvites() {
  els.adminInvitesBody.innerHTML = state.adminInvites.map((invite) => `
    <tr>
      <td>${escapeHtml(invite.displayName || '—')}</td>
      <td>${escapeHtml(invite.email || invite.id)}</td>
      <td>${formatNumber(invite.leaveBalanceDays)} jours</td>
      <td>${statusLabel(invite.status || 'pending')}</td>
      <td>${escapeHtml(formatDateTime(invite.createdAt))}</td>
    </tr>
  `).join('') || emptyRow(5, 'Aucune invitation.');
}

function renderAdminEntries() {
  const filter = els.adminStatusFilter.value;
  const entries = filter === 'all' ? state.adminEntries : state.adminEntries.filter((entry) => entry.status === filter);

  els.adminTimeBody.innerHTML = entries.slice(0, 200).map((entry) => {
    const canValidate = entry.status === 'submitted' && entry.clockOut;
    const canReopen = entry.status === 'validated';
    return `
      <tr>
        <td><strong>${escapeHtml(entry.employeeName || entry.employeeEmail || '—')}</strong></td>
        <td>${escapeHtml(formatDate(entry.date))}</td>
        <td>${escapeHtml(formatTime(entry.clockIn))}</td>
        <td>${escapeHtml(formatTime(entry.clockOut))}</td>
        <td>${numberOr(entry.breakMinutes, 0)} min</td>
        <td>${formatHours(entry.durationMinutes)}</td>
        <td>${statusLabel(entry.status)}</td>
        <td>${escapeHtml(entry.comment || '—')}</td>
        <td>
          ${canValidate ? `<button class="btn success small" data-action="validate-time" data-id="${escapeAttr(entry.id)}">Valider</button>` : ''}
          ${canReopen ? `<button class="btn secondary small" data-action="reopen-time" data-id="${escapeAttr(entry.id)}">Rouvrir</button>` : ''}
          ${!canValidate && !canReopen ? '—' : ''}
        </td>
      </tr>
    `;
  }).join('') || emptyRow(9, 'Aucun pointage.');
}

function renderAdminLeaves() {
  els.adminLeaveBody.innerHTML = state.adminLeaves.map((leave) => {
    const pending = leave.status === 'pending';
    return `
      <tr>
        <td><strong>${escapeHtml(leave.employeeName || leave.employeeEmail || '—')}</strong></td>
        <td>${escapeHtml(leave.type || '')}</td>
        <td>${escapeHtml(formatDate(leave.startDate))}</td>
        <td>${escapeHtml(formatDate(leave.endDate))}</td>
        <td>${numberOr(leave.days, 0)}</td>
        <td>${statusLabel(leave.status)}</td>
        <td>${escapeHtml(leave.employeeComment || '—')}</td>
        <td>
          ${pending ? `<button class="btn success small" data-action="approve-leave" data-id="${escapeAttr(leave.id)}">Accepter</button>` : ''}
          ${pending ? `<button class="btn danger small" data-action="refuse-leave" data-id="${escapeAttr(leave.id)}">Refuser</button>` : ''}
          ${!pending ? escapeHtml(leave.adminResponse || '—') : ''}
        </td>
      </tr>
    `;
  }).join('') || emptyRow(8, 'Aucune demande de congé.');
}

function renderAdminMetrics() {
  els.adminActiveUsers.textContent = state.adminUsers.filter((user) => user.role !== 'admin' && user.active !== false).length;
  els.adminOpenShifts.textContent = state.adminEntries.filter((entry) => entry.status === 'open').length;
  els.adminPendingLeaves.textContent = state.adminLeaves.filter((leave) => leave.status === 'pending').length;
  els.adminMonthHours.textContent = formatNumber(minutesToHours(monthMinutes(state.adminEntries)));
}

function exportEntriesCsv() {
  const rows = [
    ['Salarié', 'Email', 'Date', 'Début', 'Fin', 'Pause_minutes', 'Durée_heures', 'Statut', 'Source', 'Commentaire'],
    ...state.adminEntries.map((entry) => [
      entry.employeeName || '',
      entry.employeeEmail || '',
      entry.date || '',
      formatTime(entry.clockIn),
      formatTime(entry.clockOut),
      numberOr(entry.breakMinutes, 0),
      formatNumber(minutesToHours(entry.durationMinutes)),
      entry.status || '',
      entry.source || '',
      entry.comment || ''
    ])
  ];

  const csv = rows.map((row) => row.map(csvEscape).join(';')).join('\n');
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `heures-scea-bas-cense-${todayISO()}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function recomputeLeaveDays() {
  const start = els.leaveStart.value;
  const end = els.leaveEnd.value;
  els.leaveDays.value = start && end ? workingDaysBetween(start, end) : 0;
}

function startClock() {
  const tick = () => {
    const now = new Date();
    els.clockDate.textContent = now.toLocaleDateString('fr-FR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
    els.clockTime.textContent = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };
  tick();
  setInterval(tick, 1000);
}

function getLocation() {
  return new Promise((resolve) => {
    if (!navigator.geolocation) return resolve(null);
    navigator.geolocation.getCurrentPosition(
      (position) => resolve({
        lat: Number(position.coords.latitude.toFixed(6)),
        lng: Number(position.coords.longitude.toFixed(6)),
        accuracy: Math.round(position.coords.accuracy || 0)
      }),
      () => resolve(null),
      { enableHighAccuracy: false, timeout: 4500, maximumAge: 60000 }
    );
  });
}

function handleSnapshotError(error) {
  console.error(error);
  toast('Lecture refusée ou règles Firestore non configurées.', 'error');
}

function clearSubscriptions() {
  state.unsubscribers.forEach((unsubscribe) => unsubscribe());
  state.unsubscribers = [];
  state.openShift = null;
  state.employeeEntries = [];
  state.employeeLeaves = [];
  state.adminUsers = [];
  state.adminInvites = [];
  state.adminEntries = [];
  state.adminLeaves = [];
}

function showOnly(view) {
  els.authView.classList.toggle('hidden', view !== 'auth');
  els.employeeView.classList.toggle('hidden', view !== 'employee');
  els.adminView.classList.toggle('hidden', view !== 'admin');
  els.noAccessView.classList.toggle('hidden', view !== 'no-access');
}

function byId(id) { return document.getElementById(id); }
function docToObject(documentSnapshot) { return { id: documentSnapshot.id, ...documentSnapshot.data() }; }
function todayISO() { return toISODate(new Date()); }
function toISODate(date) { return date.toISOString().slice(0, 10); }
function numberOr(value, fallback) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
function minutesToHours(minutes) { return numberOr(minutes, 0) / 60; }
function formatNumber(value) { return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(numberOr(value, 0)); }
function formatHours(minutes) { return `${formatNumber(minutesToHours(minutes))} h`; }

function computeDurationMinutes(startIso, endIso, breakMinutes) {
  const start = new Date(startIso).getTime();
  const end = new Date(endIso).getTime();
  return Math.round((end - start) / 60000) - numberOr(breakMinutes, 0);
}

function workingDaysBetween(startISO, endISO) {
  const start = new Date(`${startISO}T00:00:00`);
  const end = new Date(`${endISO}T00:00:00`);
  if (end < start) return 0;
  let days = 0;
  const cursor = new Date(start);
  while (cursor <= end) {
    const day = cursor.getDay();
    if (day !== 0 && day !== 6) days += 1;
    cursor.setDate(cursor.getDate() + 1);
  }
  return days;
}

function monthMinutes(entries) {
  const now = new Date();
  const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  return entries
    .filter((entry) => (entry.date || '').startsWith(monthKey))
    .reduce((sum, entry) => sum + numberOr(entry.durationMinutes, 0), 0);
}

function formatDate(value) {
  if (!value) return '—';
  const date = typeof value === 'string' ? new Date(`${value}T00:00:00`) : value.toDate?.() || new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('fr-FR');
}

function formatDateTime(value) {
  if (!value) return '—';
  const date = value.toDate?.() || new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' });
}

function formatTime(value) {
  if (!value) return '—';
  const date = typeof value === 'string' ? new Date(value) : value.toDate?.() || new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

function descByDateThenCreated(a, b) {
  const dateCompare = String(b.date || '').localeCompare(String(a.date || ''));
  if (dateCompare !== 0) return dateCompare;
  return timestampMs(b.createdAt) - timestampMs(a.createdAt);
}

function descByCreated(a, b) { return timestampMs(b.createdAt) - timestampMs(a.createdAt); }
function timestampMs(value) { return value?.toDate?.().getTime?.() || new Date(value || 0).getTime() || 0; }

function statusLabel(status) {
  const labels = {
    open: 'Ouvert',
    submitted: 'À valider',
    validated: 'Validé',
    pending: 'En attente',
    approved: 'Accepté',
    refused: 'Refusé',
    accepted: 'Compte créé'
  };
  const safe = escapeAttr(status || 'pending');
  return `<span class="status ${safe}">${escapeHtml(labels[status] || status || '—')}</span>`;
}

function roleLabel(role) {
  return role === 'admin' ? '<span class="badge">Admin</span>' : '<span class="badge">Salarié</span>';
}

function emptyRow(colspan, label) {
  return `<tr><td colspan="${colspan}" class="muted">${escapeHtml(label)}</td></tr>`;
}

function csvEscape(value) {
  const text = String(value ?? '');
  return `"${text.replaceAll('"', '""')}"`;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function escapeAttr(value) { return escapeHtml(value).replaceAll('`', '&#096;'); }

function toast(message, type = '') {
  els.toast.textContent = message;
  els.toast.className = `toast ${type}`.trim();
  window.clearTimeout(toast.timer);
  toast.timer = window.setTimeout(() => els.toast.classList.add('hidden'), 4200);
}

function readableAuthError(error) {
  const code = error?.code || '';
  const messages = {
    'auth/invalid-email': 'Email invalide.',
    'auth/user-not-found': 'Aucun compte avec cet email.',
    'auth/invalid-credential': 'Email ou mot de passe incorrect.',
    'auth/wrong-password': 'Mot de passe incorrect.',
    'auth/email-already-in-use': 'Un compte existe déjà avec cet email.',
    'auth/weak-password': 'Mot de passe trop faible : 8 caractères minimum conseillés.',
    'auth/network-request-failed': 'Problème de connexion réseau.'
  };
  return messages[code] || error.message || 'Erreur d’authentification.';
}
