// 1) Créez un projet Firebase.
// 2) Activez Authentication > Email/Password.
// 3) Activez Firestore Database.
// 4) Remplacez les valeurs ci-dessous par la configuration Web Firebase.
// Documentation officielle : https://firebase.google.com/docs/web/setup

export const firebaseConfig = {
  apiKey: "REMPLACER_API_KEY",
  authDomain: "REMPLACER_PROJECT_ID.firebaseapp.com",
  projectId: "REMPLACER_PROJECT_ID",
  storageBucket: "REMPLACER_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "REMPLACER_SENDER_ID",
  appId: "REMPLACER_APP_ID"
};

export const companyDefaults = {
  name: "SCEA du Bas de la CENSE",
  contactEmail: "",
  standardDayHours: 7,
  leaveYear: new Date().getFullYear()
};
